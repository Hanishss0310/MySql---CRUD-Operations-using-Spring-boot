package com.example.mysqlcrud.repository;

import com.example.mysqlcrud.student.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student, Integer> {
    // No additional code required for basic CRUD operations
}
