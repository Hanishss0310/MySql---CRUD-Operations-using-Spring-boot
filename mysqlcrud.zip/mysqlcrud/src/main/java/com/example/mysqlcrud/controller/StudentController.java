package com.example.mysqlcrud.controller;

import com.example.mysqlcrud.repository.StudentRepository;
import com.example.mysqlcrud.student.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/students")  // Base URL for the controller
public class StudentController {

    @Autowired
    private StudentRepository repo;

    // Add new student data
    @PostMapping("/add")
    public String addData(@RequestBody Student student) {
        repo.save(student);
        return "Student added successfully";
    }

    // Fetch student data by ID
    @GetMapping("/{id}")
    public Optional<Student> getData(@PathVariable int id) {
        return repo.findById(id);
    }

    // Update student data by ID
    @PutMapping("/update/{id}")
    public String updateData(@PathVariable int id, @RequestBody Student student) {
        student.setId(id);
        repo.save(student);
        return "Student data updated successfully";
    }

    // Delete student data by ID
    @DeleteMapping("/delete/{id}")
    public String deleteData(@PathVariable int id) {
        repo.deleteById(id);
        return "Student data deleted successfully";
    }
}
