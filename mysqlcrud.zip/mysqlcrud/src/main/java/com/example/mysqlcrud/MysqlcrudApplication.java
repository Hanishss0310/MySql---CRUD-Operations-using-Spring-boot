package com.example.mysqlcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MysqlcrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(MysqlcrudApplication.class, args);
	}

}
